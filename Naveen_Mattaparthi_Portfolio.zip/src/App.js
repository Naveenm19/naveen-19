import React from "react";

export default function App() {
  return (
    <div style={ padding: "2rem", fontFamily: "sans-serif" }>
      <h1 style={ fontSize: "2rem", fontWeight: "bold" }>Naveen Mattaparthi</h1>
      <p>Full Stack Developer | Java | Spring Boot | React | AWS | Kubernetes</p>
      <a href="Naveen_Mattaparthi_Resume.pdf" download>Download Resume</a>
      <div style={ marginTop: "1rem" }>
        <a href="https://github.com/Naveenm19" target="_blank">GitHub</a> | 
        <a href="https://www.linkedin.com/in/naveen-mattaparthi-75b4041b9" target="_blank">LinkedIn</a>
      </div>
    </div>
  );
}